Included in this zip files are:
This zip file must be extracted in the resource folder of your UCH installation. After extracting it you should have the following structure:
<path to UCH>/resources\URC-INF
<path to UCH>/resources\woehlke-configuration-manager
<path to UCH>/resources\woehlke-ta
<path to UCH>/resources\woehlke-tdm
<path to UCH>/resources\license.txt
<path to UCH>/resources\readme.txt
<path to UCH>/resources\woehlke.config

The woehlke-configuration-manager can be used to add new electricity outlets to the system bei registering their Ip adresses.